//
//  TKAddEventView.swift
//  ImageInNavigationBarDemo
//
//  Created by Admin on 2019/9/28.
//  Copyright © 2019 Tung Fam. All rights reserved.
//

import Foundation
import UIKit

typealias TKEventAddButtonDidClick = () -> Void


class TKAddEventView: UIView, UITextFieldDelegate {
    
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var visualEffectView: UIVisualEffectView!
    
    var addButtonDidClick : TKEventAddButtonDidClick? = nil

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.updateVisualEffect()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.updateVisualEffect()
    }
    
    func show(_ show: Bool) {
        UIView.animate(withDuration: show ? 0.2 : 0.05) {
            self.alpha = show ? 0.0 : 0.0
        }
    }
    
    func enableShadow() {
        // corner radius
        self.layer.cornerRadius = 8

        // border
        self.layer.borderWidth = 1.0
        self.layer.borderColor = UIColor.clear.cgColor

        // shadow
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOffset = CGSize(width: 1, height: 1)
        self.layer.shadowOpacity = 0.2
        self.layer.shadowRadius = 4.0
    }
    
    /// did change theme
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        self.updateVisualEffect()
    }
    
    func updateVisualEffect() {
//        let userInterfaceStyle = self.traitCollection.userInterfaceStyle
//        self.visualEffectView.effect = UIBlurEffect(style: userInterfaceStyle == .dark ? UIBlurEffect.Style.dark : UIBlurEffect.Style.light)
    }
    
    @IBAction func buttonDidClicked(_ sender: Any) {
        if let addButtonDidClick = addButtonDidClick {
            addButtonDidClick()
        }
    }
    
}

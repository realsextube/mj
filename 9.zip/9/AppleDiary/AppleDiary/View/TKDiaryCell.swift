//
//  TKDiaryCell.swift
//  ImageInNavigationBarDemo
//
//  Created by Admin on 2019/9/29.
//  Copyright © 2019 Tung Fam. All rights reserved.
//

import UIKit

typealias TKDiaryTextFieldDidFinished = (TKDiaryCell) -> Void

class TKDiaryCell: UITableViewCell, UITextViewDelegate {
    
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var diaryTextView: UITextView!
    @IBOutlet weak var visualEffectView: UIVisualEffectView!
    var textFieldDidFinish: TKDiaryTextFieldDidFinished? = nil

    weak var tableView: UITableView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func update(_ diary: TKDiary){
        let formater = DateFormatter.init()
            formater.dateFormat = "EEEE hh:mm"
        dayLabel.text = formater.string(from: diary.createDate!)
        formater.dateFormat = "dd/M"
        dateLabel.text = formater.string(from: diary.createDate!)
        diaryTextView.text = diary.content ?? ""
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    // change color when touch up inside cell
      override func setHighlighted(_ highlighted: Bool, animated: Bool) {
          super.setHighlighted(highlighted, animated: animated)
          if highlighted {
              bgView.backgroundColor = .init(white: 0.3, alpha: 0.3)
          }
          else {
              bgView.backgroundColor = .clear
          }
      }
    
    func dismissKeyboard() {
        diaryTextView.resignFirstResponder()
    }
    
    func textViewDidChange(_ textView: UITextView) {
        let startHeight = textView.frame.size.height
        let calcHeight = textView.sizeThatFits(textView.frame.size).height

        if startHeight != calcHeight {
            UIView.setAnimationsEnabled(false)
            textView.sizeToFit()
            self.tableView.beginUpdates()
            self.tableView.endUpdates()
            UIView.setAnimationsEnabled(true)
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if let textFieldDidFinish = textFieldDidFinish {
            textFieldDidFinish(self)
        }
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        let userInterfaceStyle = self.traitCollection.userInterfaceStyle
        self.visualEffectView.effect = UIBlurEffect(style: userInterfaceStyle == .dark ? UIBlurEffect.Style.systemThinMaterialDark : UIBlurEffect.Style.regular)
    }
}

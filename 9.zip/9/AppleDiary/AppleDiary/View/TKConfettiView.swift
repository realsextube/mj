//
//  TKConfettiView.swift
//  TKConfettiView
//
//  Created by Weigang Chen on 04/10/19.
//  Copyright © 2019 Weigang Chen. All rights reserved.
//

import UIKit

public class TKConfettiView: UIView {
    
    // MARK: - Public properties
    /// How many confetti particles to emit and their velocity
    public var intensity: Float = 0.5
    
    /// Style of confetti
    public var style: ConfettiStyle = .confetti
    
    /// Shape
    public var shape: ConfettiShape = .point
    public var originPoint: CGPoint?
    
    /// Scale - defaults to auto
    public var scale: ConfettiScale = .auto
    
    /// Confetti colors
    public var colors = [UIColor(red:0.95, green:0.40, blue:0.27, alpha:1.0),
                         UIColor(red:1.00, green:0.78, blue:0.36, alpha:1.0),
                         UIColor(red:0.48, green:0.78, blue:0.64, alpha:1.0),
                         UIColor(red:0.30, green:0.76, blue:0.85, alpha:1.0),
                         UIColor(red:0.58, green:0.39, blue:0.55, alpha:1.0)]
    
    public private(set) var animating = false
    
    // MARK: - Private properties
    private var emitterLayer = CAEmitterLayer()
    
    var task1: DispatchWorkItem?
    var task2: DispatchWorkItem?
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        self.isUserInteractionEnabled = false
        self.clipsToBounds = true
    }
    
    public required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Animation
    /// Start animating confetti
    public func start() {
        start(duration: 0)
    }
    
    public func start(duration: CGFloat) {
        if animating {
            print("Ignore, confetti is still animating")
            return
        }
        
        emitterLayer.removeFromSuperlayer()
        setupShape()
        setupColors()
        setupDuration(duration:duration)
        layer.addSublayer(emitterLayer)
        animating = true
    }
    
    private func setupShape(){
        switch shape {
        case .line:
            if originPoint == nil { originPoint = CGPoint(x: frame.size.width / 2.0, y: 0) }
            emitterLayer.emitterPosition = originPoint!
            emitterLayer.emitterShape = CAEmitterLayerEmitterShape.line
            emitterLayer.emitterSize = CGSize(width: frame.size.width, height: 1)
        case .point:
            if originPoint == nil { originPoint = CGPoint(x: frame.size.width / 2.0, y: frame.size.width / 2.0) }
            emitterLayer.emitterPosition = originPoint!
            emitterLayer.emitterShape = CAEmitterLayerEmitterShape.point
            emitterLayer.emitterSize = CGSize(width: 1, height: 1)
        }
    }
    
    private func setupColors() {
        let cells = colors.map({
            return confettiWithColor(color: $0)
        })
        emitterLayer.emitterCells = cells
    }
    
    private func setupDuration(duration: CGFloat){
        
        task1?.cancel()
        task2?.cancel()
        
        if duration > 0 {
            let lifeTime = 14.0 * intensity
            let minDuration = min(Double(duration), Double(lifeTime))
            let maxDuration = max(Double(duration), Double(lifeTime))
            
            task1 = DispatchWorkItem { [weak self] in
                self?.emitterLayer.birthRate = 0
                print("confetti clear ...")
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + minDuration, execute:task1!)

            task2 = DispatchWorkItem { [weak self] in
                self?.stop(clear: true)
                self?.removeFromSuperview() // dealloc
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + maxDuration, execute:task2!)
        }
    }
    
    /// Stop animating confetti
    /// - parameter clear: Immediately remove confetti view
    public func stop(clear: Bool = false) {
        if clear {
            emitterLayer.removeFromSuperlayer()
        } else {
            emitterLayer.birthRate = 0
        }
        animating = false
    }
    
    private func confettiWithColor(color: UIColor) -> CAEmitterCell {
        let confetti = CAEmitterCell()
        confetti.scale = scale.scaleValue
        confetti.birthRate = 4.0 * intensity
        confetti.lifetime = 10.0 * intensity
        confetti.lifetimeRange = 0
        confetti.color = color.cgColor
        confetti.velocity = CGFloat(350.0 * intensity)
        confetti.velocityRange = CGFloat(80.0 * intensity)
        confetti.scaleRange = CGFloat(intensity)
        confetti.scaleSpeed = CGFloat(-0.1 * intensity)
        confetti.contents = style.image?.cgImage
        confetti.alphaSpeed = -1.0 / (10.0 * intensity)

        /// QA: pi or pi * 2 
        confetti.emissionLongitude = CGFloat(Double.pi)
        confetti.emissionRange = CGFloat(Double.pi)
        confetti.emissionLatitude = CGFloat(Double.pi)
        
        if shape == .line {
            confetti.emissionLongitude = CGFloat(Double.pi)
            confetti.emissionRange = CGFloat(Double.pi)
        }
                
        //        confetti.spin = CGFloat(3.5 * intensity)
        //        confetti.spinRange = CGFloat(4.0 * intensity)
        
        return confetti
    }
    
    deinit {
        print("Confetti view dealloc!")
    }
}

/// Shape & Style
extension TKConfettiView {
    
    public enum ConfettiShape {
        case line
        case point
    }
    
    public enum ConfettiStyle {
        case confetti
        case diamond
        case star
        case triangle
        case customImage(UIImage)
        
        /// Image for associatied ConfettiStyle
        internal var image: UIImage! {
            
            // Framework bundle location for assets
            let bundle = Bundle(for: TKConfettiView.self)
            
            switch self {
            case .confetti:
                return UIImage(named: "sks_confetti", in: bundle, compatibleWith: nil)!
            case .diamond:
                return UIImage(named: "sks_diamond", in: bundle, compatibleWith: nil)!
            case .star:
                return UIImage(named: "sks_star", in: bundle, compatibleWith: nil)!
            case .triangle:
                return UIImage(named: "sks_triangle", in: bundle, compatibleWith: nil)!
            case let .customImage(customImage):
                return customImage
            }
        }
        
    }
}

/// Scale size
extension TKConfettiView {
    public enum ConfettiScale {
        case small
        case large
        case auto
        case custom(CGFloat)
        
        /// Scale value
        internal var scaleValue: CGFloat {
            switch self {
            case .small:
                return 0.5
            case .large:
                return 1.0
            case .auto:
                // Use large size if on an iPad, small if not
                if UIDevice.current.userInterfaceIdiom == .pad {
                    return 1.0
                } else {
                    return 0.5
                }
            case let .custom(customScale):
                return customScale
            }
        }
    }
}

//
//  TKTaskCell.swift
//  ImageInNavigationBarDemo
//
//  Created by Admin on 2019/9/28.
//  Copyright © 2019 Tung Fam. All rights reserved.
//

import UIKit

typealias TKTaskCheckButtonDidClick = (TKTaskCell) -> Void
typealias TKTaskTextFieldDidFinished = (TKTaskCell) -> Void
typealias TKTaskRepeatButtonDidClick = (TKTaskCell) -> Void
typealias TKTaskDidLongPressed = (TKTaskCell) -> Void


class TKTaskCell: UITableViewCell, UITextFieldDelegate {
    
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var taskTextField: UITextField!
    @IBOutlet weak var checkButton: UIButton!
    @IBOutlet weak var checkImage: UIImageView!
    @IBOutlet weak var visualEffectView: UIVisualEffectView!
    
    @IBOutlet weak var repeatButton: UIButton!
    
    var checkButtonDidClick: TKTaskCheckButtonDidClick? = nil
    var textFieldDidFinished :TKTaskTextFieldDidFinished? = nil
    var repeatButtonDidClick :TKTaskRepeatButtonDidClick? = nil
    var pressDidLongPressed :TKTaskDidLongPressed? = nil
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        taskTextField.attributedPlaceholder = NSAttributedString(string: "Please add your task",
        attributes: [NSAttributedString.Key.foregroundColor: UIColor.init(named: "placehoder")!])
        taskTextField.textColor = UIColor(named: "cell_text")
        
        let ges = UILongPressGestureRecognizer.init(target: self, action: #selector(didLongPressed))
        self.contentView.addGestureRecognizer(ges)
    }

    func update(_ task: TKTask) {
        checkImage.image = UIImage.init(systemName: task.checked ? "checkmark.circle.fill" : "circle")
        if task.repetition {
            repeatButton.tintColor = UIColor.init(red: 0, green: 144.0/255.0, blue: 81.0/255.0, alpha: 1.0)
            repeatButton.alpha = 0.9
        }
        else {
            repeatButton.tintColor = UIColor.init(named: "repeat_disable")
            repeatButton.alpha = 0.25
        }
        
        if task.checked {
            let text = task.name ?? ""
            let attributedText = NSMutableAttributedString(string: text)
            attributedText.addAttribute(NSAttributedString.Key.strikethroughStyle, value: NSUnderlineStyle.single.rawValue, range: NSMakeRange(0, text.count))
            attributedText.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.init(named: "cell_underline_text")!, range: NSMakeRange(0, text.count))
            taskTextField.attributedText = attributedText
        }
        else {
            taskTextField.attributedText = nil
            taskTextField.text = task.name
        }
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    // change color when touch up inside cell
    override func setHighlighted(_ highlighted: Bool, animated: Bool) {
        super.setHighlighted(highlighted, animated: animated)
        if highlighted {
            bgView.backgroundColor = .init(white: 0.3, alpha: 0.3)
        }
        else {
            bgView.backgroundColor = .clear
        }
    }

    @IBAction func doCheck(_ sender: Any) {
        
        if self.isEditing { return }
        
        if let checkButtonDidClick = checkButtonDidClick {
            checkButtonDidClick(self)
        }
    }
    
    @IBAction func doRepeat(_ sender: Any) {
        
        if self.isEditing { return }
        
        if let repeatButtonDidClick = repeatButtonDidClick {
            repeatButtonDidClick(self)
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if let textFieldDidFinished = textFieldDidFinished {
            textFieldDidFinished(self)
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        if let textFieldDidFinished = textFieldDidFinished {
            textFieldDidFinished(self)
        }
        
        return true
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        let userInterfaceStyle = self.traitCollection.userInterfaceStyle
        self.visualEffectView.effect = UIBlurEffect(style: userInterfaceStyle == .dark ? UIBlurEffect.Style.systemThinMaterialDark : UIBlurEffect.Style.regular)
    }
    
    @objc func didLongPressed() {
        if self.isEditing { return }
        
        if let pressDidLongPressed = pressDidLongPressed {
            pressDidLongPressed(self)
        }
    }
}

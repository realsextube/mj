//
//  TKDayView.swift
//  ImageInNavigationBarDemo
//
//  Created by Admin on 2019/9/30.
//  Copyright © 2019 Tung Fam. All rights reserved.
//

import UIKit

class TKDayView: UIView {

    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var dayLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.updateDate()
    }
    
    func updateDate(_ date: Date = Date.init()) {
        dateLabel.text = date.stringForSecionHeader()
        monthLabel.text = date.month()
        dayLabel.text = date.day()
    }
}

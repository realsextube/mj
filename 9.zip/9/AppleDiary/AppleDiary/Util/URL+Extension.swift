//
//  URL+Extension.swift
//  AppleDiary
//
//  Created by Samuel on 2019/10/7.
//  Copyright © 2019 TK. All rights reserved.
//

import Foundation

extension URL {
    static var documentsDirectory: URL? {
        let documentsDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        return URL.init(string: documentsDirectory)
    }

    static func urlInDocumentsDirectory(with filename: String) -> URL? {
        return documentsDirectory?.appendingPathComponent(filename)
    }
}

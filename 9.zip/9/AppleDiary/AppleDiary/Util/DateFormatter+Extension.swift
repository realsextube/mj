//
//  DateFormatter+Extension.swift
//  AppleDiary
//
//  Created by Samuel on 2019/10/6.
//  Copyright © 2019 TK. All rights reserved.
//

import Foundation

extension Date {

    func stringForSecionHeader() -> String {

        let formater = DateFormatter.init()
        formater.dateFormat = "EEEE, d MMMM"

        return formater.string(from: self)
    }
    
    func month() -> String {
        let formater = DateFormatter.init()
        formater.dateFormat = "MMM"

        return formater.string(from: self)
    }
    
    func day() -> String {
        let formater = DateFormatter.init()
        formater.dateFormat = "d"

        return formater.string(from: self)
    }
}

//
//  AppDelegate.swift
//  AppleDiary
//
//  Created by Admin on 2019/10/3.
//  Copyright © 2019 TK. All rights reserved.
//

import UIKit
import CoreData

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        #if targetEnvironment(simulator)
        print("Simulator")
        #else
        print("Device")
        #endif
        
        
        // test core data code
//        TKCoredata.shared.deleteAll("TKTaskCopyAction")
        
//        let tasks = TKCoredata.shared.fetchObjects("TKTask") as! [TKTask]
//        for task in tasks {
//            print("user = \(task.userid) name = \(task.name) create date = \(task.createDate) repetition = \(task.repetition)")
//        }
        
//        handleException()
        return true
    }
    
    // MARK: UISceneSession Lifecycle
    
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
    
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        
    }
    
    func handleException() {
        NSSetUncaughtExceptionHandler { exception in
            print("NSSetUncaughtExceptionHandler \(exception) ")
        }
        
        signal(SIGABRT) { _ in
            print("SIGABRT \(Thread.callStackSymbols)")
        }
        
        signal(SIGILL) { _ in
            print("SIGILL \(Thread.callStackSymbols)")
        }
        
        signal(SIGSEGV) { _ in
            print("SIGSEGV \(Thread.callStackSymbols)")
        }
        
        signal(SIGFPE) { _ in
            print("SIGFPE \(Thread.callStackSymbols)")
        }
        
        signal(SIGBUS) { _ in
            print("SIGBUS \(Thread.callStackSymbols)")
        }
        
        signal(SIGPIPE) { _ in
            print("SIGPIPE \(Thread.callStackSymbols)")
        }
    }
}


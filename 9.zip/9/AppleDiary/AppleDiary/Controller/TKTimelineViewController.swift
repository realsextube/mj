//
//  TKTimelineViewController.swift
//  ImageInNavigationBarDemo
//
//  Created by Admin on 2019/9/29.
//  Copyright © 2019 Tung Fam. All rights reserved.
//

import UIKit

class TKTimelineViewController: UITableViewController, UIGestureRecognizerDelegate {
   
    weak var cubeScrollView: UIScrollView? // to trigger swipe animation

    var diaries : [TKDiary] = []
    var user: TKUser?
    var backgroundImageChanged: Bool = true
    var date: Date = Date.init() // default is today
   
    var swipeGesture: UISwipeGestureRecognizer?
    var navSwipeGesture: UISwipeGestureRecognizer?

    override func viewDidLoad() {
        super.viewDidLoad()
        user = TKCoredata.shared.currentUser()
        setupNavigationBar()
        setupTableView()
        loadToadyDiaries()
        
        self.refreshControl = UIRefreshControl.init()
        self.refreshControl?.addTarget(self, action: #selector(refreshPreviousDiaries), for: .valueChanged)
    }
    
    @objc func refreshPreviousDiaries() {
        self.refreshControl?.beginRefreshing()
        DispatchQueue.main.asyncAfter(deadline: .now()+0.3) {
            self.refreshControl?.endRefreshing()
            var previousDiaries = self.previousDiaries()
            if previousDiaries.count > 0 {
                previousDiaries.append(contentsOf: self.diaries)
                self.diaries = previousDiaries
                self.tableView.reloadData()
            }
        }
    }
    
    func loadToadyDiaries() {
        guard TKCoredata.shared.currentUser() != nil else { return }
        self.diaries = TKCoredata.shared.fetchDiaries(of: date).reversed()
    }
    
    func previousDiaries() -> [TKDiary] {
        guard TKCoredata.shared.currentUser() != nil else { return []}

        let limit = 10
        let result: [TKDiary] = TKCoredata.shared.fetchDiaries(before: self.date, limit: limit, offset: self.diaries.count).reversed()
        
        return result
    }
    
    func setupNavigationBar() {
        // remove seprator line && clear background image
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.titleTextAttributes = [            NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.setBackgroundImage(UIImage.init(named: "Untitled2"), for: .default)
        navigationController?.navigationBar.setValue(true, forKey: "hidesShadow")
        
        navSwipeGesture = UISwipeGestureRecognizer.init(target: self, action: #selector(swipeFromLeftToRight))
        navSwipeGesture!.direction = .right
        navSwipeGesture!.delegate = self
        self.navigationController?.navigationBar.addGestureRecognizer(navSwipeGesture!)
    }
    
    func setupTableView() {
        self.setupTableViewBackgroundImage()
        tableView.backgroundColor = .clear
        self.tableView.estimatedRowHeight = 200
        self.tableView.rowHeight = UITableView.automaticDimension
        
        self.tableView.register(UINib.init(nibName: "TKDiaryCell", bundle: nil), forCellReuseIdentifier: "TKDiaryCell")
        self.tableView.register(UINib.init(nibName: "TKAddCell", bundle: nil), forCellReuseIdentifier: "TKAddCell")
        
        self.tableView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(hideKeyboard)))
    }
    
    func setupTableViewBackgroundImage(){
        if backgroundImageChanged {
            let imgView = UIImageView.init(image: UIImage.loadTimelineBackgroundImageOfUser(user))
            imgView.contentMode = .scaleAspectFill
            tableView.backgroundView = imgView
            
            backgroundImageChanged = false
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setupTableViewBackgroundImage()
        navigationController?.navigationBar.setBackgroundImage((self.tableView.backgroundView as! UIImageView).image, for: .default)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: UIWindow.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: UIWindow.keyboardWillHideNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(willEnterForeground),
                                               name: UIApplication.willEnterForegroundNotification,
                                                   object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(timelineBackgroundImageChanged),
                                               name: NSNotification.Name(rawValue: "timelineBackgroundImageChanged"),
                                               object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        NotificationCenter.default.removeObserver(self)
    }    
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardHeight = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue.height {
            print("keyboardHeight = \(keyboardHeight)")
            let addEventHeight: CGFloat = 60.0
            let height = -self.tableView(self.tableView, heightForFooterInSection: 0) + addEventHeight
            tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: height, right: 0)
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        UIView.animate(withDuration: 0.2, animations: {
            // For some reason adding inset in keyboardWillShow is animated by itself but removing is not, that's why we have to use animateWithDuration here
            self.tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        })
    }
    
    @objc func willEnterForeground() {
        self.tableView.reloadData()
    }
    
    @objc func hideKeyboard() {
        view.endEditing(true)
        removeEmptyDiaries()
    }
    
    @objc func timelineBackgroundImageChanged() {
        backgroundImageChanged = true
    }
}

extension TKTimelineViewController {
    // MARK: TableView datasource & delegate
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return diaries.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cell = tableView.dequeueReusableCell(withIdentifier: "TKDiaryCell", for: indexPath) as! TKDiaryCell
        cell.tableView = self.tableView
        cell.diaryTextView.text = diaries[indexPath.row].content ?? ""
        cell.textFieldDidFinish = { cell in
            if let indexPath = tableView.indexPath(for: cell) {
                self.diaries[indexPath.row].content = cell.diaryTextView.text
            }
        }
        cell.update(diaries[indexPath.row])
        return cell
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let dayView: TKDayView = Bundle.main.loadNibNamed("TKDayView", owner: nil, options: nil)?.last as! TKDayView
        return dayView
    }
    
    override func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let addDiaryView: TKAddEventView = Bundle.main.loadNibNamed("TKAddEventView", owner: nil, options: nil)?.last as! TKAddEventView
//        addDiaryView.backgroundColor = .red
        addDiaryView.button.setTitle("Diary", for: .normal)
        addDiaryView.addButtonDidClick = {
            self.addDiary()
        }
        
        swipeGesture = UISwipeGestureRecognizer.init(target: self, action: #selector(swipeFromLeftToRight))
        swipeGesture!.direction = .right
        swipeGesture!.delegate = self
        addDiaryView.addGestureRecognizer(swipeGesture!)
        
        return addDiaryView
    }
    
    /// Perfer swipe gesture over cell's swipe gesture
    /// https://developer.apple.com/documentation/uikit/touches_presses_and_gestures/coordinating_multiple_gesture_recognizers/preferring_one_gesture_over_another
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                           shouldBeRequiredToFailBy otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        // Do not begin the pan until the swipe fails.
        if (gestureRecognizer == self.swipeGesture || gestureRecognizer == self.navSwipeGesture)
            && String(describing: type(of: otherGestureRecognizer)) == "_UISwipeActionPanGestureRecognizer" {
            otherGestureRecognizer.state = .failed
            return true
        }
        return false
    }

    @objc func swipeFromLeftToRight() {
        if let cubeScrollView = cubeScrollView {
            cubeScrollView.setValue(0.4, forKeyPath: "contentOffsetAnimationDuration")
            cubeScrollView.setContentOffset(CGPoint.init(x: 0, y: 0), animated: true)
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 35
    }
    
    override func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        let cellCount: CGFloat = fmin(CGFloat(self.diaries.count), 3)
        let cellTotalHeight: CGFloat = 20.0 + 44.0 + 35.0 + (60.0 * cellCount)
        return self.view.frame.size.height - cellTotalHeight
    }

    override func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        if tableView.isEditing {
            return .none
        }
        return .delete
    }
    
    //    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
    //        return !(self.tasks.count == 1 && indexPath.row == 0)
    //    }
    
    override func tableView(_ tableView: UITableView, shouldIndentWhileEditingRowAt indexPath: IndexPath) -> Bool {
        return false
    }
    
    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let movedObject = self.diaries[sourceIndexPath.row]
        diaries.remove(at: sourceIndexPath.row)
        diaries.insert(movedObject, at: destinationIndexPath.row)
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == .delete) {
            let diary = diaries[indexPath.row]
            diaries.remove(at: indexPath.row)
            TKCoredata.shared.delete(diary)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
}

extension TKTimelineViewController {
    
    func addDiary(_ diary: String = "") {
        guard TKCoredata.shared.currentUser() != nil else { return }

        let diary = TKCoredata.shared.newDiary(content: diary)
        self.diaries.append(diary)
        
        self.tableView.beginUpdates()
        self.tableView.insertRows(at: [IndexPath.init(row: self.diaries.count - 1, section: 0)], with: .fade)
        self.tableView.endUpdates()
        
        if let cell = self.tableView.visibleCells.last as? TKDiaryCell {
            cell.diaryTextView.becomeFirstResponder()
        }
    }
    
    func removeEmptyDiaries() {
        var removeDiraies: [TKDiary] = []
        var indexes: [IndexPath] = []
        var i = 0
        
        for diary in diaries {
            if diary.content == "" {
                removeDiraies.append(diary)
                indexes.append(IndexPath.init(row: i, section: 0))
            }
            i = i + 1
        }
        
        diaries = diaries.filter{$0.content != ""}
        
        self.tableView.beginUpdates()
        self.tableView.deleteRows(at: indexes, with: .fade)
        self.tableView.endUpdates()
    }
}

//
//  UIViewController+Util.swift
//  AppleDiary
//
//  Created by Samuel on 2019/11/2.
//  Copyright © 2019 TK. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {

    func presentLoginVC(_ parent: UIViewController? = nil, _ animated: Bool = true, _ completion: (() -> Void)? = nil) {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let loginVC = storyboard.instantiateViewController(withIdentifier: "TKLoginVC")
        loginVC.modalPresentationStyle = .pageSheet
        loginVC.isModalInPresentation = true
        
        let vc = parent ?? self
        vc.present(loginVC, animated: animated, completion: completion)
    }
}

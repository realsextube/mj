//
//  TKLoginViewController.swift
//  AppleDiary
//
//  Created by Samuel on 2019/10/7.
//  Copyright © 2019 TK. All rights reserved.
//

import UIKit

class TKLoginViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    
    @IBAction func doLogin(_ sender: Any) {
        
        var user: TKUser? = TKCoredata.shared.lastLoginUser()
        if user == nil {
            user = TKCoredata.shared.anonymousUser()
        }
        
        if let user = user, let loginUser = TKCoredata.shared.login(user) {
            print("login user \(loginUser.uid!) successfully!")
            self.dismiss(animated: true, completion: nil)
        }
    }
}

//
//  TKMineViewController.swift
//  ImageInNavigationBarDemo
//
//  Created by Admin on 2019/9/28.
//  Copyright © 2019 Tung Fam. All rights reserved.
//

import UIKit

class TKMineViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    
    var user: TKUser!
    private lazy var imagePicker = UIImagePickerController()
    
    var imageIndex: Int = 0 // 0 today, 1 diary
    
    @IBOutlet weak var userLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        user = TKCoredata.shared.currentUser()!
        // Do any additional setup after loading the view.
        
        self.title = "Mine \(user.uid!)"
        userLabel.text = self.title
        userLabel.backgroundColor = .black
        userLabel.isHidden = true
    }
    
    @IBAction func changeTodayBackgroundImage(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            imageIndex = 0
            
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary
            imagePicker.allowsEditing = false
            
            present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: { () -> Void in
            
        })
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        self.dismiss(animated: true, completion: { () -> Void in
            
        })
        
        // get the documents directory url
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        // choose a name for your image
        let fileName = self.imageIndex == 0 ? "today_bg.png" : "diary_bg.png"
        // create the destination file url to save your image
        let fileURL = documentsDirectory.appendingPathComponent(fileName)
        // get your UIImage jpeg data representation and check if the destination file url already exists
        if FileManager.default.fileExists(atPath: fileURL.path) {
            do {
                try FileManager.default.removeItem(at: fileURL)
            } catch {
                print("error delete file:", error)
            }
        }
        
        if let data = (info[UIImagePickerController.InfoKey.originalImage] as! UIImage).pngData(),
            !FileManager.default.fileExists(atPath: fileURL.path) {
            do {
                // writes the image data to disk
                try data.write(to: fileURL)
                if self.imageIndex == 0 {
                    user.todayimageurl = fileURL.absoluteString
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "todayBackgroundImageChanged"), object: nil)
                }
                else if self.imageIndex == 1 {
                    user.diaryimageurl = fileURL.absoluteString
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "timelineBackgroundImageChanged"), object: nil)
                }
                print("file saved: \(fileURL.absoluteString)")
                
            } catch {
                print("error saving file:", error)
            }
        }
    }
    
    @IBAction func changeDiaryBackgroundImage(_ sender: Any) {
        imageIndex = 1
        
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = true
        
        present(imagePicker, animated: true, completion: nil)
    }
    
    @IBAction func logout(_ sender: Any) {
        
        if let navigationController = self.navigationController {
            navigationController.popViewController(animated: false)
            self.presentLoginVC(navigationController) {
                TKCoredata.shared.logout()
            }
        }
    }
    
}

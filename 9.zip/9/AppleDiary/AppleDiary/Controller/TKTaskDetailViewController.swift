//
//  TKTaskDetailViewController.swift
//  ImageInNavigationBarDemo
//
//  Created by Admin on 2019/9/28.
//  Copyright © 2019 Tung Fam. All rights reserved.
//

import UIKit

class TKTaskDetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}

//
//  ViewController.swift
//  PagingDemo
//
//  Created by Admin on 2019/9/29.
//  Copyright © 2019 TK. All rights reserved.
//

import UIKit

class TKPageViewController: UIPageViewController, UIPageViewControllerDelegate, UIPageViewControllerDataSource {

    var pageSubViewControllers: [UIViewController] = []
    var pageControl: UIPageControl = UIPageControl.init(frame: CGRect.init(x: 100, y: 100, width: 100, height: 40))
    var pendingIndex: Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.dataSource = self
        self.delegate = self
        
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc1 = storyboard.instantiateViewController(withIdentifier: "TKNavTodayTVC")
        let vc2 = storyboard.instantiateViewController(withIdentifier: "TKNavTimelineTVC")
        
        pageSubViewControllers = [vc1, vc2]
        self.setViewControllers([vc1], direction: .forward, animated: true, completion: { (done) in
        })
        
        pageControl.numberOfPages = pageSubViewControllers.count
        pageControl.isUserInteractionEnabled = false
        self.view.addSubview(pageControl)
        
        // disable scroll, because the scroll is conflict with cell's swipe delete gesture
        self.scrollview()?.isScrollEnabled = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        if let index = pageSubViewControllers.firstIndex(of: viewController) {
            if index > 0 {
                return pageSubViewControllers[index - 1]
            }
        }
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        if let index = pageSubViewControllers.firstIndex(of: viewController) {
            if index < (pageSubViewControllers.count - 1) {
                return pageSubViewControllers[index + 1]
            }
        }
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if completed {
            pageControl.currentPage = pendingIndex
        }
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, willTransitionTo pendingViewControllers: [UIViewController]) {
        pendingIndex = pageSubViewControllers.firstIndex(of: pendingViewControllers.first!)!
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let width: CGFloat = 100.0
        let height: CGFloat = 40.0
        pageControl.frame = CGRect.init(x:  CGFloat(self.view.frame.size.width) / 2 - width / 2, y: self.view.frame.height - height, width: width, height: height)
    }
    
    
    func scrollToDiaryPage() {
        self.setViewControllers([self.pageSubViewControllers[1]], direction: .forward, animated: true, completion: { (done) in
            self.pageControl.currentPage = 1

        })
    }
    
    func scrollToTaskPage() {
        self.setViewControllers([self.pageSubViewControllers[0]], direction: .reverse, animated: true, completion: { (done) in
            self.pageControl.currentPage = 0
        })
    }
}

extension UIPageViewController {

    func scrollview() -> UIScrollView? {
        for view in self.view.subviews {
            if let subView = view as? UIScrollView {
                return subView
            }
        }
        
        return nil
    }
}

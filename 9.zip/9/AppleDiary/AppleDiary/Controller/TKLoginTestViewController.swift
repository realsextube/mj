//
//  TKLoginTestViewController.swift
//  AppleDiary
//
//  Created by Samuel on 2019/10/7.
//  Copyright © 2019 TK. All rights reserved.
//

import UIKit

class TKLoginTestViewController: UIViewController {
    
    @IBOutlet weak var userTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let lastUser = TKCoredata.shared.lastLoginUser() {
            userTextField.text = lastUser.uid
        }
    }
    
    @IBAction func doRegister(_ sender: Any) {
        
        guard let uid = userTextField.text, uid.count > 0 else {
            print("register failed, uid can not be null or empty!")
            return
        }
        
        if let user = TKCoredata.shared.findUser(uid) {
            print("register failed, uid = \(String(describing: user.uid)) already exist!")
            return
        }
          
        let user = TKCoredata.shared.registerUser(uid: uid)
        print("Register user = \(String(describing: user.uid)) [\(String(describing: user.name))] successful!")
    }
    
    @IBAction func doLogin(_ sender: Any) {
        let uid = userTextField.text ?? ""
        
        var user: TKUser? = nil
        
        if uid == "" {
            user = TKCoredata.shared.anonymousUser()
        }
        else {
            user = TKCoredata.shared.findUser(uid)
        }
        
        if let user = user, let loginUser = TKCoredata.shared.login(user) {
            print("login user \(loginUser.uid!) successfully!")
            self.dismiss(animated: true, completion: nil)
        }
        else {
            print("Login failed! Can not find exist user = \(uid)!")
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
}

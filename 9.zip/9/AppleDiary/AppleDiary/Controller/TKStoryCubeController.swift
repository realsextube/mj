//
//  TKStoryCubeController.swift
//  AppleDiary
//
//  Created by Samuel on 2019/10/21.
//  Copyright © 2019 TK. All rights reserved.
//

import UIKit

class TKStoryCubeController: UIViewController {
    var scrollView = StoriesScrollView()
    var navToday: UINavigationController? = nil
    var navDiary: UINavigationController? = nil
    
    var pageControl: UIPageControl = UIPageControl.init(frame: CGRect.init(x: 100, y: 100, width: 100, height: 40))
    var pendingIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadSubviews()
        scrollView.isScrollEnabled = false // disable scroll because conflict with cell swipe delete action
        
        pageControl.numberOfPages = Int(scrollView.contentSize.width / scrollView.frame.size.width)
        pageControl.isUserInteractionEnabled = false
        self.view.addSubview(pageControl)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    func loadSubviews() {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        navToday = storyboard.instantiateViewController(withIdentifier: "TKNavTodayTVC") as? UINavigationController
        navDiary = storyboard.instantiateViewController(withIdentifier: "TKNavTimelineTVC") as? UINavigationController
        
        if let vc = navToday?.topViewController as? TKTodayTableViewController {
            vc.cubeScrollView = self.scrollView
        }
        
        if let vc = navDiary?.topViewController as? TKTimelineViewController {
            vc.cubeScrollView = self.scrollView
        }
        
        layoutSubviews()
    }
    
    func layoutSubviews() {
        scrollView.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
        scrollView.delegate = self
        view.addSubview(scrollView)
        scrollView.setDataSource(with: [navToday!.view, navDiary!.view])
    }
}

extension TKStoryCubeController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let visibleViews = self.scrollView.visibleViews().sorted(by: {$0.frame.origin.x > $1.frame.origin.x} ) // 1
        let xOffset = scrollView.contentOffset.x // 2
        
        // 3
        let rightViewAnchorPoint = CGPoint(x: 0, y: 0.5)
        let leftViewAnchorPoint = CGPoint(x: 1, y: 0.5)
        
        // 4
        var transform = CATransform3DIdentity
        transform.m34 = 1.0 / 1000
        
        // 5
        let leftSideOriginalTransform = CGFloat(90 * Double.pi / 180.0)
        let rightSideCellOriginalTransform = -CGFloat(90 * Double.pi / 180.0)
        
        if let viewFurthestRight = visibleViews.first, let viewFurthestLeft =  visibleViews.last {
            let hasCompletedPaging = (xOffset / scrollView.frame.width).truncatingRemainder(dividingBy: 1) == 0
            var rightAnimationPercentComplete = hasCompletedPaging ? 0 :1 - (xOffset / scrollView.frame.width).truncatingRemainder(dividingBy: 1)

            if xOffset < 0 { rightAnimationPercentComplete -= 1 }
            viewFurthestRight.transform(to: rightSideCellOriginalTransform * rightAnimationPercentComplete, with: transform)
            viewFurthestRight.setAnchorPoint(rightViewAnchorPoint)
            
              if  xOffset > 0 {
                let leftAnimationPercentComplete = (xOffset / scrollView.frame.width).truncatingRemainder(dividingBy: 1)
                viewFurthestLeft.transform(to: leftSideOriginalTransform * leftAnimationPercentComplete, with: transform)
                viewFurthestLeft.setAnchorPoint(leftViewAnchorPoint)
               }
        }
        
        pageControl.currentPage = Int(scrollView.contentOffset.x / scrollView.frame.size.width)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let width: CGFloat = 100.0
        let height: CGFloat = 40.0
        pageControl.frame = CGRect.init(x:  CGFloat(self.view.frame.size.width) / 2 - width / 2, y: self.view.frame.height - height, width: width, height: height)
    }
}

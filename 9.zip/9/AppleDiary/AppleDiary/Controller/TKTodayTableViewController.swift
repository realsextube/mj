//
//  TKTodayTableViewController.swift
//  ImageInNavigationBarDemo
//
//  Created by Tung Fam on 11/14/17.
//  Copyright © 2017 Tung Fam. All rights reserved.
//

import UIKit

class TKTodayTableViewController: UITableViewController, UIGestureRecognizerDelegate {

    weak var cubeScrollView: UIScrollView? // to trigger swipe animation
    
    var mineButton: TKInNavigationBarButton?
    var tasks: [TKTask] = []
    var date: Date = Date.init()
    
    var user: TKUser!
    var todayImageURL: String? = nil
    
    var swipeGesture: UISwipeGestureRecognizer?
    var navSwipeGesture: UISwipeGestureRecognizer?
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Today"
        setupNavigationBar()
        setupMineButton(nil)
        setupTableView()
    }
    
    func setupNavigationBar() {
        // remove seprator line && clear background image
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.titleTextAttributes = [            NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.setValue(true, forKey: "hidesShadow")
        let tap = UITapGestureRecognizer(target: self, action: #selector(didTapNavBar))
        self.navigationController?.navigationBar.addGestureRecognizer(tap)
        
        navSwipeGesture = UISwipeGestureRecognizer.init(target: self, action: #selector(swipeFromRightToLeft))
        navSwipeGesture!.direction = .left
        navSwipeGesture!.delegate = self
        self.navigationController?.navigationBar.addGestureRecognizer(navSwipeGesture!)
    }
    
    @objc func didTapNavBar() {
        print("user did tap navigation bar")
    }
    
    func setupMineButton(_ user: TKUser?) {
        if mineButton == nil {
            mineButton = TKInNavigationBarButton.init()
            mineButton?.addTarget(self, action: #selector(mineButtonTapped), for: UIControl.Event.touchUpInside)
            navigationController?.navigationBar.addSubview(mineButton!)
        }
        mineButton?.setImage(UIImage.loadAvatarImageOfUser(user), for: .normal)
    }
    
    func setupTableView() {
        setupTableViewBackgroundImage(user)
        tableView.backgroundColor = .clear
        tableView.register(UINib.init(nibName: "TKTaskCell", bundle: nil), forCellReuseIdentifier: "TKTaskCell")
        tableView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(hideKeyboard)))
    }
    
    func setupTableViewBackgroundImage(_ user: TKUser?) {
         let image = UIImage.loadTodayBackgroundImageOfUser(user)
         let imgView = UIImageView.init(image: image)
         imgView.contentMode = .scaleAspectFill
         tableView.backgroundView = imgView
         navigationController?.navigationBar.setBackgroundImage((self.tableView.backgroundView as! UIImageView).image, for: .default)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        if !TKCoredata.shared.isLogined() {
            let successful = autoLogin() 
            print("Auto login " + (successful ? "\(user!.uid!)  successful" : "failed"))
        }
        
        if let user = TKCoredata.shared.currentUser() {
            self.user = user
            date = Date.init()
            
            self.tasks = loadTasks(date)
            tableView.reloadData()
            
            setupTableViewBackgroundImage(user)
            setupMineButton(user)
        }
        else {
            presentLoginVC()
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: UIWindow.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: UIWindow.keyboardWillHideNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(willEnterForeground),
                                               name: UIApplication.willEnterForegroundNotification,
                                               object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(todayBackgroundImageChanged),
                                               name: NSNotification.Name(rawValue: "todayBackgroundImageChanged"),
                                               object: nil)
    }
    
    func autoLogin() -> Bool {
        let supportAutoLogin = true
        
        if !supportAutoLogin {
            print("Auto login not supported!")
            return false
        }
        
        if let user = TKCoredata.shared.lastLoginUser() {
            if let loginUser = TKCoredata.shared.login(user) {
                self.user = loginUser
                print("Auto login user = \(loginUser.uid!)")
                return true
            }
        }
        
        print("Auto login failed!")
        return false
    }
    
    func loadTasks(_ date: Date) -> [TKTask] {
        let repeatTasks = TKCoredata.shared.copyRepeatTasks(date: date)
        print("\(repeatTasks.count) repeat task(s) copied successfully.")
        return TKCoredata.shared.fetchTasks(date: date)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        mineButton?.show(false)
        
        NotificationCenter.default.removeObserver(self)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        mineButton?.show(true)
        
        /// refresh date if date has changed, eg: 23:59 -> 01:01 when user scroll back
        if !Calendar.current.isDateInToday(self.date) {
            refreshDate()
        }
        
        // check whether the tasks is empty, add a new task to prompt
        if self.user != nil, self.tasks.isEmpty {
            DispatchQueue.main.asyncAfter(deadline: .now()) {
                self.addTask(order: Int16(self.tasks.count))
            }
        }
    }
    
    func refreshDate() {
        let date = Date.init()
        self.tasks = loadTasks(date)
        self.date = date
        self.tableView.reloadData()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }
    
    override func scrollViewDidScroll(_ scrollView: UIScrollView) {
        mineButton?.update()
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardHeight = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue.height {
            print("keyboardHeight = \(keyboardHeight)")
            let addEventHeight: CGFloat = 60.0
            let height = -self.tableView(self.tableView, heightForFooterInSection: 0) + addEventHeight
            
            tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: height, right: 0)
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        UIView.animate(withDuration: 0.2, animations: {
            // For some reason adding inset in keyboardWillShow is animated by itself but removing is not, that's why we have to use animateWithDuration here
            self.tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        })
    }
    
    @objc func todayBackgroundImageChanged() {
        setupTableViewBackgroundImage(user)
    }
    
    @objc func willEnterForeground() {
        refreshDate()
    }
    
    @objc func hideKeyboard() {
        view.endEditing(true)
        removeEmptyTasks()
    }
}

extension TKTodayTableViewController {
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TKTaskCell", for: indexPath) as! TKTaskCell
        let task = tasks[indexPath.row]
        cell.update(task)
        cell.checkButtonDidClick = { cell in
            if !task.checked, let indexPath = tableView.indexPath(for: cell) {
                self.playStarAnimation(index: indexPath)
                let impactFeedbackgenerator = UIImpactFeedbackGenerator(style: .medium)
                impactFeedbackgenerator.prepare()
                impactFeedbackgenerator.impactOccurred()
            }
            task.checked = !task.checked
            cell.update(task)
        }
        cell.repeatButtonDidClick = { cell in
            if let indexPath = tableView.indexPath(for: cell) {
                self.tasks[indexPath.row].repetition = !self.tasks[indexPath.row].repetition
                cell.update(task)
                if self.tasks[indexPath.row].repetition {
                    let impactFeedbackgenerator = UIImpactFeedbackGenerator(style: .light)
                    impactFeedbackgenerator.prepare()
                    impactFeedbackgenerator.impactOccurred()
                }
            }
        }
        cell.textFieldDidFinished = { cell in
            if let indexPath = tableView.indexPath(for: cell) {
                self.tasks[indexPath.row].name = cell.taskTextField.text ?? ""
                cell.update(task)
            }
        }
        cell.pressDidLongPressed = { cell in
            self.enableEditMode(true)
        }
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        performSegue(withIdentifier: "SegueIDTaskDetail", sender: nil)
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let dayView: TKDayView = Bundle.main.loadNibNamed("TKDayView", owner: nil, options: nil)?.last as! TKDayView
        return dayView
    }
    
    override func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let addTaskView: TKAddEventView = Bundle.main.loadNibNamed("TKAddEventView", owner: nil, options: nil)?.last as! TKAddEventView
        addTaskView.addButtonDidClick = {
            self.addTask(order: Int16(self.tasks.count))
        }
        
        swipeGesture = UISwipeGestureRecognizer.init(target: self, action: #selector(swipeFromRightToLeft))
        swipeGesture!.direction = .left
        swipeGesture!.delegate = self
        addTaskView.addGestureRecognizer(swipeGesture!)
        
        return addTaskView
    }

    @objc func swipeFromRightToLeft() {
        if let cubeScrollView = cubeScrollView {
            cubeScrollView.setValue(0.4, forKeyPath: "contentOffsetAnimationDuration")
            cubeScrollView.setContentOffset(CGPoint.init(x: cubeScrollView.frame.size.width, y: 0), animated: true)
        }
    }
    
    /// Perfer swipe gesture over cell's swipe gesture
    /// https://developer.apple.com/documentation/uikit/touches_presses_and_gestures/coordinating_multiple_gesture_recognizers/preferring_one_gesture_over_another
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                           shouldBeRequiredToFailBy otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        // Do not begin the pan until the swipe fails.
        if (gestureRecognizer == self.swipeGesture || gestureRecognizer == self.navSwipeGesture)
            && String(describing: type(of: otherGestureRecognizer)) == "_UISwipeActionPanGestureRecognizer" {
            otherGestureRecognizer.state = .failed
            return true
        }
        return false
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 35
    }
    
    override func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        let cellCount: CGFloat = fmin(CGFloat(self.tasks.count), 3)
        let cellTotalHeight: CGFloat = 20.0 + 44.0 + 35.0 + (60.0 * cellCount)
        return self.view.frame.size.height - cellTotalHeight
    }
    
    override func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        if tableView.isEditing {
               return .none
          }
        return .delete
    }

//    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
//        return !(self.tasks.count == 1 && indexPath.row == 0)
//    }
    
    override func tableView(_ tableView: UITableView, shouldIndentWhileEditingRowAt indexPath: IndexPath) -> Bool {
        return false
    }
    
    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let movedObject = self.tasks[sourceIndexPath.row]
        tasks.remove(at: sourceIndexPath.row)
        tasks.insert(movedObject, at: destinationIndexPath.row)
        
        var i: Int16 = 0
        for task in tasks {
            task.order = i
            print("task = \(task)")
            i = i + 1
        }
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == .delete) {
            let task = tasks[indexPath.row]
            tasks.remove(at: indexPath.row)
            TKCoredata.shared.delete(task)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
//
//    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
//        let delete = UITableViewRowAction(style: .destructive, title: "Delete") { (action, indexPath) in
//            // delete item at indexPath
//        }
//
//        let share = UITableViewRowAction(style: .normal, title: "Disable") { (action, indexPath) in
//            // share item at indexPath
//        }
//
//        share.backgroundColor = UIColor.blue
//
//        return [delete, share]
//    }
}

extension TKTodayTableViewController {
    // MARK: Utility
    func addTask(order: Int16) {
        let task = TKCoredata.shared.newTask(order: order)
        self.tasks.append(task)
        
        self.tableView.beginUpdates()
        self.tableView.insertRows(at: [IndexPath.init(row: self.tasks.count - 1, section: 0)], with: .fade)
        self.tableView.endUpdates()
        
        if let cell = self.tableView.visibleCells.last as? TKTaskCell {
            cell.taskTextField.becomeFirstResponder()
        }
    }
    
    func removeEmptyTasks() {
        var removeTasks: [TKTask] = []
        var indexes: [IndexPath] = []
        var i = 0
        
        for task in tasks {
            if task.name == "" {
                removeTasks.append(task)
                indexes.append(IndexPath.init(row: i, section: 0))
            }
            i = i + 1
        }
        
        tasks = tasks.filter{$0.name != ""}
        
        for task in removeTasks {
            TKCoredata.shared.delete(task)
        }
        
        self.tableView.beginUpdates()
        self.tableView.deleteRows(at: indexes, with: .fade)
        self.tableView.endUpdates()
    }
    
    @objc func mineButtonTapped(sender: UIButton)
    {
        print("press mine button")
        performSegue(withIdentifier: "SegueIDMine", sender: nil)
    }
    
    func playStarAnimation(index: IndexPath) {
        let window :UIWindow = self.keyWindow
        
        let rectOfCellInTableView = tableView.rectForRow(at: index)
        let rectOfCellInSuperview = tableView.convert(rectOfCellInTableView, to: window)
        
        let confettiView = TKConfettiView(frame: window.bounds)
        confettiView.originPoint = CGPoint.init(x: 30, y: rectOfCellInSuperview.origin.y + rectOfCellInSuperview.size.height / 2)
        confettiView.intensity = 0.2
        confettiView.shape = .point
        confettiView.style = .star
        confettiView.scale = .auto
        confettiView.start(duration: 0.3)
        
        // The confetti view will automatically remove itself when animation is end. Don't worry.
        window.addSubview(confettiView)
        window.bringSubviewToFront(confettiView)
    }
    
    func enableEditMode(_ enable: Bool) {
        if enable {
            mineButton?.removeFromSuperview()
            mineButton = nil
            navigationItem.rightBarButtonItem = UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(finishEditing))
            navigationItem.rightBarButtonItem?.tintColor = .white
            self.tableView.setEditing(true, animated: true)
        }
        else {
            setupMineButton(user)
            navigationItem.rightBarButtonItem = nil
        }
    }
    
    @objc func finishEditing() {
        enableEditMode(false)
        self.tableView.setEditing(false, animated: true)
    }
}

extension UIImage {
    static func loadAvatarImageOfUser(_ user: TKUser?) -> UIImage {
        if let user = user, let imageurl = user.avatar, let image = TKLoadImage(imageurl) {
             return image
        }
        return UIImage.init(named: "captain")!
    }
    
    static func loadTodayBackgroundImageOfUser(_ user: TKUser?) -> UIImage {
        if let user = user, let imageurl = user.todayimageurl, let image = TKLoadImage(imageurl) {
             return image
        }
        return UIImage.init(named: "today_bg")!
    }
    
    static func loadTimelineBackgroundImageOfUser(_ user: TKUser?) -> UIImage {
        if let user = user, let imageurl = user.diaryimageurl, let image = TKLoadImage(imageurl) {
             return image
        }
        return UIImage.init(named: "diary_bg")!
    }
    
    static func TKLoadImage(_ filename: String) -> UIImage? {
        
        do {
            guard let url = URL.init(string: filename) else { return nil }
            let data = try Data.init(contentsOf: url)
            if let image = UIImage.init(data: data) {
                return image
            }
        } catch  {
            print("load image error: \(error.localizedDescription) path \(filename) ")
        }
        
        return UIImage.init(named: filename)
    }
}


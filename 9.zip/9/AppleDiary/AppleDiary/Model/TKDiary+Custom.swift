//
//  TKDiary+Custom.swift
//  AppleDiary
//
//  Created by Admin on 2019/10/9.
//  Copyright © 2019 TK. All rights reserved.
//

import CoreData

extension TKCoredata {
    
    func newDiary(_ createDate: Date = Date.init(), content: String = "") -> TKDiary {
        
        let diary = insertNewObject("TKDiary") as! TKDiary
        diary.userid = currentUser()?.uid
        diary.content = content
        diary.createDate = createDate
        
        return diary
    }
    
    // fetch dairies of specific day
    func fetchDiaries(of date: Date) -> [TKDiary] {
        
        let request = NSFetchRequest<NSFetchRequestResult>.init(entityName: "TKDiary")
        
        request.predicate = predicateOfSameDay(date)
        request.sortDescriptors = [NSSortDescriptor(key: #keyPath(TKDiary.createDate), ascending: false)]

        do {
            let result:[Any] = try context().fetch(request)
            if result.count > 0 {
                
                for d in result {
                    if let d = d as? TKDiary {
                        print("diary name = \(String(describing: d.content)) \n createDate = \(String(describing: d.createDate))")
                    }
                }
                
                return result as! [TKDiary]
            }
        } catch {
            print("error = \(error.localizedDescription)")
        }

        return []
    }
    
    // fetch diaries before date
    func fetchDiaries(before date: Date, limit: Int, offset: Int = 0) -> [TKDiary] {
        let request = NSFetchRequest<NSFetchRequestResult>.init(entityName: "TKDiary")
        
        request.predicate = NSPredicate(format: "createDate =< %@ AND userid == %@", argumentArray: [date, currentUser()!.uid!])
        request.sortDescriptors = [NSSortDescriptor(key: #keyPath(TKDiary.createDate), ascending: false)]
        request.fetchLimit = limit
        if offset > 0 {
            request.fetchOffset = offset
        }
        
        do {
            let result:[Any] = try context().fetch(request)
            if result.count > 0 {
                
                for d in result {
                    if let d = d as? TKDiary {
                        print("diary name = \(String(describing: d.content)) \n createDate = \(String(describing: d.createDate))")
                    }
                }
                
                return result as! [TKDiary]
            }
        } catch {
            print("error = \(error.localizedDescription)")
        }

        return []
    }
    
    
}

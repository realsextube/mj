//
//  TKUser+Custom.swift
//  AppleDiary
//
//  Created by Samuel on 2019/10/6.
//  Copyright © 2019 TK. All rights reserved.
//

import CoreData

extension TKCoredata {
    
    private static var user: TKUser? = nil
    static let anonymousId = "8705" // default value local anonymous id

    
    // if uid == nil or "", means anonymous login
    func login(_ uid: String) -> TKUser? {
        if let user = findUser(uid) {
            TKCoredata.user = user
            TKCoredata.shared.setLastLogin(user: user) // this is import for auto login, log the last login account
            return TKCoredata.user
        }
        return nil
    }
    
    func login(_ user: TKUser) -> TKUser? {
        if let uid = user.uid {
            return login(uid)
        }
        return nil
    }
    
    func anonymousUser() -> TKUser {
        var user = findUser(TKCoredata.anonymousId)
        if user == nil {
            user = registerAnonymousUser()
        }
        
        return user!
    }
    
    func findUser(_ uid: String) -> TKUser? {
        
        if uid == "" {
            return nil
        }
        
        let users = fetchObjects("TKUser") as! [TKUser]
        
        for user in users {
            if user.uid == uid {
                return user
            }
        }
        
        return nil
    }
    
    func currentUser() -> TKUser? {
        return TKCoredata.user
    }
    
    func lastLoginUser() -> TKUser? {
        
        let users = fetchObjects("TKUser") as? [TKUser]
        if let users = users {
            for user in users {
                if user.isLastLogin { // found last login user
                    return user
                }
            }
        }
        
        return nil
    }
    
    func isLogined() -> Bool {
        return TKCoredata.user != nil
    }
    
    private func registerAnonymousUser() -> TKUser {
        return registerUser(uid:TKCoredata.anonymousId, name:"Anonymous")
    }
    
    func registerUser(uid: String, name: String = "User") -> TKUser {
        
        var user = findUser(uid)
        
        if user == nil {
            user = insertNewObject("TKUser") as? TKUser
            user!.uid = uid
            user!.createDate = Date.init()
            user!.isAnonymous = uid == TKCoredata.anonymousId
            user!.name = name
            user!.isLastLogin = false
            user!.avatar = "captain"
            user!.diaryimageurl = "diary_bg"
            user!.todayimageurl = "today_bg"
        }
        
        return user!
    }
    
    func setLastLogin(user current: TKUser) {
        
        let users = fetchObjects("TKUser") as! [TKUser]
        for user in users {
            user.isLastLogin = false
        }
        current.isLastLogin = true
        print("clear other user login flags. Set current last login = \(current.uid!)")
    }
    
    func logout() {
        TKCoredata.user?.isLastLogin = false
        TKCoredata.user = nil
    }
    
    func deleteAllData(of user: TKUser){
        deleteObjects(of: user, entity: "TKTask")
        deleteObjects(of: user, entity: "TKDiary")
        deleteObjects(of: user, entity: "TKTaskCopyAction")
        TKCoredata.shared.delete(user)
    }
    
    private func deleteObjects(of user: TKUser, entity: String) {
        let predicate = NSPredicate.init(format: "userid == %@", user.uid!)
        let objs = TKCoredata.shared.fetchObjects(entity, predicate: predicate) as [NSManagedObject]
        
        for obj in objs {
            TKCoredata.shared.delete(obj)
        }
    }
    
}

//
//  TKCoredata.swift
//  AppleDiary
//
//  Created by Samuel on 2019/10/5.
//  Copyright © 2019 TK. All rights reserved.
//

import UIKit
import CoreData

class TKCoredata: NSObject {
    
    static let shared = TKCoredata()

    lazy var persistentContainer: NSPersistentCloudKitContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
        */
        let container = NSPersistentCloudKitContainer(name: "AppleDiary")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                 
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()

    // MARK: - Core Data Saving support

    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    func context () -> NSManagedObjectContext {
        return persistentContainer.viewContext
    }
}


extension TKCoredata {
    
    // new object
    func insertNewObject(_ entityName: String) -> NSManagedObject {
        return NSEntityDescription.insertNewObject(forEntityName: entityName, into: context())
    }
    
    // fetch a exist object
    func fetchObject(_ entityName: String) -> NSManagedObject? {
        let objs : [NSManagedObject]? = fetchObjects(entityName, predicate: nil, sortDescriptors: nil)
        return objs?.first
    }
    
    // fetch object
    func fetchObject(_ entityName: String, predicate: NSPredicate?) -> NSManagedObject? {
        let objs : [NSManagedObject]? = fetchObjects(entityName, predicate: predicate, sortDescriptors: nil)
        return objs?.first
    }
    
    // fetch objects
    func fetchObjects(_ entityName: String) -> [NSManagedObject] {
        return fetchObjects(entityName, predicate: nil, sortDescriptors: nil)
    }
    
    // fetch objects
    func fetchObjects(_ entityName: String, predicate: NSPredicate?) -> [NSManagedObject] {
        return fetchObjects(entityName, predicate: predicate, sortDescriptors: nil)
    }
    
    // fetch objects
    func fetchObjects(_ entityName: String, predicate: NSPredicate?, sortDescriptors: [NSSortDescriptor]?, _ limit: Int? = nil) -> [NSManagedObject] {
        
        let request = NSFetchRequest<NSFetchRequestResult>.init(entityName: entityName)

        if let predicate = predicate {
            request.predicate = predicate
        }
        
        if let sortDescriptors = sortDescriptors {
            request.sortDescriptors = sortDescriptors
        }
        
        if let limit = limit {
            request.fetchLimit = limit
        }
        
        do {
            let result:[NSManagedObject] = try context().fetch(request) as! [NSManagedObject]
            if result.count > 0 {
                return result
            }
        } catch {
            print("error = \(error.localizedDescription)")
        }
        
        return []
    }
    
    // delete object
    func delete(_ object:NSManagedObject) {
        self.context().delete(object)
    }
    
    func deleteAll(_ entity: String, _ predictate: NSPredicate? = nil) {
        
        print("count \(count(entity))")
        let objs = fetchObjects(entity, predicate: predictate)
        
        for obj in objs {
            self.context().delete(obj)
        }
        print("count \(count(entity, predictate))")
        
        // # Q&A 20001
//        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
//        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
//        deleteRequest.resultType = .resultTypeObjectIDs
//
//        do {
//            let result = try context().execute(deleteRequest) as! NSBatchDeleteResult
//            let changes: [AnyHashable: Any] = [
//                NSDeletedObjectsKey: result.result as! [NSManagedObjectID]
//            ]
//            NSManagedObjectContext.mergeChanges(fromRemoteContextSave: changes, into: [context()])
//            let count = self.count(entity)
//            print("batch delete result = \(result) count = \(count)")
//        } catch {
//            fatalError("Failed to execute request: \(error)")
//        }
    }
    
    // count
    func count(_ entity: String, _ predictate: NSPredicate? = nil) -> Int {
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
        if let predictate = predictate {
            request.predicate = predictate
        }
        
        do {
            return try context().count(for: request)
        } catch {
            print("error = \(error.localizedDescription)")
            return 0
        }
    }
}

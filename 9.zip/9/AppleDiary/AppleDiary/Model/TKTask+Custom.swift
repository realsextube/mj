//
//  TKTask+Custom.swift
//  AppleDiary
//
//  Created by Samuel on 2019/10/5.
//  Copyright © 2019 TK. All rights reserved.
//

import CoreData

extension TKCoredata {
    
    func newTask(order: Int16 = Int16.max, _ date: Date = Date.init()) -> TKTask {
        
        let task = insertNewObject("TKTask") as! TKTask
        task.checked = false
        task.createDate = date
        task.name = ""
        task.order = order
        task.type = "check"
        task.userid = currentUser()?.uid
        task.repetition = true
        
        return task
    }
    
    func copyTask(_ task: TKTask, _ date: Date = Date.init()) -> TKTask {
        
        let taskNew = insertNewObject("TKTask") as! TKTask
        taskNew.checked = false // the copied task should not be checked
        taskNew.createDate = date
        taskNew.name = task.name
        taskNew.order = task.order
        taskNew.type = task.type
        taskNew.userid = task.userid
        taskNew.repetition = task.repetition
        
        return taskNew
    }
    
    func fetchTasks(date: Date, repetition: Bool? = nil) -> [TKTask] {
        
        let request = NSFetchRequest<NSFetchRequestResult>.init(entityName: "TKTask")
        if let repetition = repetition {
            let p1 = predicateOfSameDay(date)
            let p2 = NSPredicate.init(format: "repetition == %@ AND userid == %@", NSNumber.init(value: repetition), currentUser()!.uid!)
            request.predicate = NSCompoundPredicate.init(type: .and, subpredicates: [p1, p2])
        }
        else {
            let p1 = predicateOfSameDay(date)
            request.predicate = p1
        }
        
        request.sortDescriptors = [NSSortDescriptor(key: #keyPath(TKTask.order), ascending: true)] // sort by order

        do {
            let result:[Any] = try context().fetch(request)
            if result.count > 0 {
                
                for t in result {
                    if let t = t as? TKTask {
                        print("task name = \(String(describing: t.name)) \n createDate = \(String(describing: t.createDate))")
                    }
                }
                
                return result as! [TKTask]
            }
        } catch {
            print("error = \(error.localizedDescription)")
        }

        return []
    }
    
    func predicateOfSameDay(_ date: Date) -> NSPredicate {
        
        let startDate = self.startDate(date)
        let endDate = self.endDate(date)
        return NSPredicate(format: "createDate >= %@ AND createDate =< %@ AND userid == %@", argumentArray: [startDate, endDate, currentUser()!.uid!])
    }
    
    func startDate(_ date: Date) -> Date {
        let calendar = NSCalendar.init(identifier: NSCalendar.Identifier.gregorian)
        var components = calendar!.components(NSCalendar.Unit(rawValue: NSCalendar.Unit.year.rawValue |
            NSCalendar.Unit.month.rawValue |
            NSCalendar.Unit.day.rawValue |
            NSCalendar.Unit.hour.rawValue |
            NSCalendar.Unit.minute.rawValue |
            NSCalendar.Unit.second.rawValue), from: date)
        components.hour = 00
        components.minute = 00
        components.second = 00
        return calendar!.date(from: components)!
    }
    
    func endDate(_ date: Date) -> Date {
        let calendar = NSCalendar.init(identifier: NSCalendar.Identifier.gregorian)
         var components = calendar!.components(NSCalendar.Unit(rawValue: NSCalendar.Unit.year.rawValue |
             NSCalendar.Unit.month.rawValue |
             NSCalendar.Unit.day.rawValue |
             NSCalendar.Unit.hour.rawValue |
             NSCalendar.Unit.minute.rawValue |
             NSCalendar.Unit.second.rawValue), from: date)
        components.hour = 23
        components.minute = 59
        components.second = 59
         return calendar!.date(from: components)!
    }
    
    func copyRepeatTasks(date: Date) -> [TKTask] {
        
        if isCopyRepeatTasksCompleted(date) {
            return []
        }
        
        guard let lastDayDate = lastDayOfRepeatTask(date: date) else {
            completeRepeatAction(date)
            return []
        }
        
        let tasks = fetchRepeatTasksOfDay(date: lastDayDate)
        let newTasks = copyTasks(tasks)

        completeRepeatAction(date)
        
        return newTasks
    }
    
    func lastDayOfRepeatTask(date: Date) -> Date? {
        let startDate = self.startDate(date)
        let predicate = NSPredicate(format: "createDate < %@ AND repetition == %@ AND userid == %@", argumentArray: [startDate, NSNumber.init(value: true), currentUser()!.uid!])
        let sortDescriptors = [NSSortDescriptor(key: #keyPath(TKTask.createDate), ascending: false)] // sort by order

        let results = fetchObjects("TKTask", predicate: predicate, sortDescriptors: sortDescriptors, 1) as! [TKTask]
        if results.count > 0 {
            return results[0].createDate
        }
        
        return nil
    }
    
    func fetchRepeatTasksOfDay(date: Date) -> [TKTask] {
        return fetchTasks(date: date, repetition: true)
    }
    
    func copyTasks(_ tasks: [TKTask]) -> [TKTask] {
        
        var results: [TKTask] = []
        for task in tasks {
            let newTask = self.copyTask(task)
            results.append(newTask)
        }
        return results
    }
    
    func isCopyRepeatTasksCompleted(_ date: Date) -> Bool {
        
        let request = NSFetchRequest<NSFetchRequestResult>.init(entityName: "TKTaskCopyAction")
        request.predicate = predicateOfSameDay(date)

        do {
            let result:[Any] = try context().fetch(request)
            return result.count > 0
        } catch {
            print("error = \(error.localizedDescription)")
        }

        return false
    }
    
    func completeRepeatAction(_ date: Date) {
        let repeatAction = insertNewObject("TKTaskCopyAction") as! TKTaskCopyAction
        repeatAction.createDate = date
        repeatAction.userid = currentUser()?.uid
    }
    
}

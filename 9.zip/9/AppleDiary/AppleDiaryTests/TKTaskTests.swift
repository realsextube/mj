//
//  AppleDiaryTests.swift
//  AppleDiaryTests
//
//  Created by Admin on 2019/10/3.
//  Copyright © 2019 TK. All rights reserved.
//

import XCTest
@testable import AppleDiary

class TKTaskTests: XCTestCase {
    
    let testUserId = "123456" // test user id
    var testUser: TKUser? = nil
    let cd = TKCoredata.shared
    
    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        login(testUserId)
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        cd.deleteAllData(of: self.testUser!)
    }
    
    func login(_ uid: String) {
        let registerUser = cd.registerUser(uid: testUserId)
        self.testUser = cd.login(registerUser)
    }
    
    func testTestUserLogin() {
        XCTAssert(cd.isLogined() == true)
        XCTAssert(testUser != nil)
        
    }
    
    func testClearTasks() {
        cd.deleteAll("TKTask")
        let count = TKCoredata.shared.count("TKTask", NSPredicate.init(format: "userid = %@", argumentArray: [testUser!.uid!]))
        XCTAssert(count == 0)
    }
    
    func testClearDiaries() {
        cd.deleteAll("TKDiary")
        let count = TKCoredata.shared.count("TKDiary", NSPredicate.init(format: "userid = %@", argumentArray: [testUser!.uid!]))
        XCTAssert(count == 0)
    }
    
    func testClearData() {
        cd.deleteAllData(of: testUser!)
        var count = TKCoredata.shared.count("TKTask", NSPredicate.init(format: "userid = %@", argumentArray: [testUserId]))
        XCTAssert(count == 0)
        count = TKCoredata.shared.count("TKDiary", NSPredicate.init(format: "userid = %@", argumentArray: [testUserId]))
        XCTAssert(count == 0)
        count = TKCoredata.shared.count("TKTaskCopyAction", NSPredicate.init(format: "userid = %@", argumentArray: [testUserId]))
        XCTAssert(count == 0)
        count = TKCoredata.shared.count("TKUser", NSPredicate.init(format: "uid = %@", argumentArray: [testUserId]))
        XCTAssert(count == 0)
        login(testUserId)
        
    }
    
    func testTomorrow() {
        let tomorrow = Date.init(timeIntervalSinceNow: 20 * 60 * 60)
        
        let tasks0 = TKCoredata.shared.fetchTasks(date: tomorrow)
        XCTAssert(tasks0.count == 0)
        
        var task = TKCoredata.shared.newTask()
        task.name = "tomorrow"
        task.createDate = Date.init(timeIntervalSinceNow: 24 * 60 * 60)
        TKCoredata.shared.saveContext()
        
        let tasks = TKCoredata.shared.fetchTasks(date: tomorrow)
        XCTAssert(tasks.count == 1)
        
        task = tasks[0]
        XCTAssert(task.name == "tomorrow")
    }
    
    func testYesterday() {
        let yesterday = Date.init(timeIntervalSinceNow: -24 * 60 * 60)
        
        let tasks0 = TKCoredata.shared.fetchTasks(date: yesterday)
        XCTAssert(tasks0.count == 0)
        
        var task = TKCoredata.shared.newTask()
        task.name = "yesterday"
        task.createDate = Date.init(timeIntervalSinceNow: -24 * 60 * 60)
        TKCoredata.shared.saveContext()
        
        let tasks = TKCoredata.shared.fetchTasks(date: yesterday)
        XCTAssert(tasks.count == 1)
        
        task = tasks[0]
        XCTAssert(task.name == "yesterday")
    }
    
    func testToday() {
        let today = Date.init()
        
        let tasks0 = TKCoredata.shared.fetchTasks(date: today)
        XCTAssert(tasks0.count == 0)
        
        var task = TKCoredata.shared.newTask()
        task.name = "today 1"
        task.createDate = Date.init()
        
        task = TKCoredata.shared.newTask()
        task.name = "today 2"
        task.createDate = Date.init(timeIntervalSinceNow: 30 * 60)
        TKCoredata.shared.saveContext()
        
        let tasks = TKCoredata.shared.fetchTasks(date: today)
        XCTAssert(tasks.count == 2)
        
        task = tasks[0]
        XCTAssert(task.name == "today 1" || task.name == "today 2")
        
        task = tasks[1]
        XCTAssert(task.name == "today 1" || task.name == "today 2")
    }
    
//    func testMultipleDays() {
//
//        var task = TKCoredata.shared.newTask()
//        task.name = "today 1"
//        task.date = Date.init()
//
//        task = TKCoredata.shared.newTask()
//        task.name = "today 2"
//        task.date = Date.init(timeIntervalSinceNow: -10 * 60 * 60)
//
//        task = TKCoredata.shared.newTask()
//        task.name = "today 3"
//        task.date = Date.init(timeIntervalSinceNow: 30 * 60)
//
//        task = TKCoredata.shared.newTask()
//        task.name = "today 4"
//        task.date = Date.init(timeIntervalSinceNow: 60 * 60)
//
//        task = TKCoredata.shared.newTask()
//        task.name = "tomorrow 1"
//        task.date = Date.init(timeIntervalSinceNow: 13 * 60 * 60)
//
//        task = TKCoredata.shared.newTask()
//        task.name = "tomorrow 2"
//        task.date = Date.init(timeIntervalSinceNow: 26 * 60 * 60)
//
//        task = TKCoredata.shared.newTask()
//        task.name = "tomorrow 3"
//        task.date = Date.init(timeIntervalSinceNow: 34 * 60 * 60)
//
//        task = TKCoredata.shared.newTask()
//        task.name = "yester day 1"
//        task.date = Date.init(timeIntervalSinceNow: -14 * 60 * 60)
//
//        TKCoredata.shared.saveContext()
//
//
//        var tasks = TKCoredata.shared.fetchTasks(date: Date.init())
//        XCTAssert(tasks.count == 4)
//
//        tasks = TKCoredata.shared.fetchTasks(date: Date.init(timeIntervalSinceNow: 11 * 60 * 60))
//        XCTAssert(tasks.count == 3)
//
//        tasks = TKCoredata.shared.fetchTasks(date: Date.init(timeIntervalSinceNow: -14 * 60 * 60))
//        XCTAssert(tasks.count == 1)
//    }
    
    
    func testHasRepeatTasks() {
        XCTAssert(TKCoredata.shared.isCopyRepeatTasksCompleted(Date.init()) == false)
    }
    
    func testCopyRepeatTasks() {
        
        var task = TKCoredata.shared.newTask()
        task.name = "yesterday 1"
        task.createDate = Date.init(timeIntervalSinceNow: -24 * 60 * 60)
        
        task = TKCoredata.shared.newTask()
        task.name = "yesterday 2"
        task.createDate = Date.init(timeIntervalSinceNow: -25 * 60 * 60)
        
        task = TKCoredata.shared.newTask()
        task.name = "yesterday 3"
        task.createDate = Date.init(timeIntervalSinceNow: -26 * 60 * 60)
        TKCoredata.shared.saveContext()
        
        let date = Date.init()
        var tasks = TKCoredata.shared.fetchTasks(date: date)
        XCTAssert(tasks.count == 0)
        
        tasks = TKCoredata.shared.copyRepeatTasks(date: date) 
        for task in tasks {
            task.name = task.name?.replacingOccurrences(of: "yesterday", with: "today")
        }
        
        tasks = TKCoredata.shared.fetchTasks(date: date)
        XCTAssert(tasks.count == 3)
        
        for task in tasks {
            XCTAssert(task.name!.contains("today"))
        }
    }
    
    
    func testChangeUserLogin() {

        XCTAssert(self.testUser!.uid == testUserId, "This is not a test user \(testUserId)")
        
        // add a new task in the current user
        let task = cd.newTask()
        let name = "change user = \(testUser!.uid!) login"
        task.name = name
        task.checked = true
        
        // logout
        cd.logout()
        testUser = nil
        
        // anonymous login
        let anonymous = cd.anonymousUser()
        if let user = cd.login(anonymous) {
            self.testUser = user
        }
        else {
            XCTAssert(false, "should not login failed!")
        }
        
        // fecth previous added task
        var tasks = cd.fetchTasks(date: Date.init())
        
        for task in tasks {
            // the task should not be exist
            XCTAssert(task.name != name)
        }
  
        // logout anonymous user
        cd.logout()
        testUser = nil
        
        // login test user again
        login(testUserId)
        
        tasks = cd.fetchTasks(date: Date.init())
        var result: TKTask? = nil
        for task in tasks {
            if task.name == name {
                result = task
                break;
            }
        }
        XCTAssert(result != nil)
        XCTAssert(result!.checked)
    }
    
    //    func testPerformanceExample() {
    //        // This is an example of a performance test case.
    //        self.measure {
    //            // Put the code you want to measure the time of here.
    //        }
    //    }
    
}

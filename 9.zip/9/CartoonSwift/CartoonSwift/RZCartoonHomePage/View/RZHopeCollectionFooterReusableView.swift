//
//  RZHopeCollectionFooterReusableView.swift
//  CartoonSwift
//
//  Created by Mac on 2019/7/26.
//  Copyright © 2019 rz. All rights reserved.
//

import UIKit

class RZHopeCollectionFooterReusableView: RZBaseCollectionReusableView {
    
    override func initUI() {
        
    }
    
}

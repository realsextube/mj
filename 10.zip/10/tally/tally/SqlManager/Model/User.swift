//
//  User.swift
//  tally
//
//  Created by 李志敬 on 2019/3/16.
//  Copyright © 2019 李志敬. All rights reserved.
//

import UIKit

class User: NSObject {
    
    var name: String?
    var email: String?
    var userid: String?
    var id: Int64 = 0
    
}

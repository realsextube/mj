//
//  Summary.swift
//  tally
//
//  Created by 李志敬 on 2019/3/19.
//  Copyright © 2019 李志敬. All rights reserved.
//

import UIKit

class Summary: NSObject {

    var id: Int64 = 0
    var userid: String?
    var totalamount: String?
    var date:String?
    var tallytype: Int = 0
    var summarytype: Int = 0
    
}

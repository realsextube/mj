//
//  ConsumeType.swift
//  tally
//
//  Created by 李志敬 on 2019/3/19.
//  Copyright © 2019 李志敬. All rights reserved.
//

import UIKit

class ConsumeType: NSObject {

    var id: Int64 = 0
    var keyName: String?
    var keyValue: String?
    var count: Int64 = 0
    var pid: Int64 = 0
    
    
}

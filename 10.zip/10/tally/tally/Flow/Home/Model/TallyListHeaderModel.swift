//
//  TallyListHeaderModel.swift
//  tally
//
//  Created by 李志敬 on 2019/3/18.
//  Copyright © 2019 李志敬. All rights reserved.
//

import UIKit

class TallyListHeaderModel: NSObject {

    var date: String?
    var week: String?
    var amount: String?
    
}

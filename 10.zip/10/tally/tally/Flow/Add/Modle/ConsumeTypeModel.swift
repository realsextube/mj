//
//  ConsumeTypeModel.swift
//  tally
//
//  Created by 李志敬 on 2019/3/15.
//  Copyright © 2019 李志敬. All rights reserved.
//

import UIKit

class ConsumeTypeModel: NSObject {

    var name: String?
    var imageName: String?
    var highImageName: String?
    var isSelected: Bool = false
    var tallyType: TallyModel.TalleyType?
    
}

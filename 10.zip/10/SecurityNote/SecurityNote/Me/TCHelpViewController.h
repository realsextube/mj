//
//  TCHelpViewController.h
//  SecurityNote
//
//  Created by HTC on 14-10-2.
//  Copyright (c) 2014年 JoonSheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TCHelpViewController : UIViewController

@end

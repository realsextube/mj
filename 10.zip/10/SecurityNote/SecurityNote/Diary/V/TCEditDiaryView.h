//
//  TCEditDiaryView.h
//  SecurityNote
//
//  Created by HTC on 14-9-29.
//  Copyright (c) 2014年 JoonSheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TCEditDiaryView : UIViewController

@property (nonatomic, assign) int ids;

@end

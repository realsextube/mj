//
//  TCShowViewController.h
//  GLUTJWsystem
//
//  Created by joonsheng on 14-8-27.
//  Copyright (c) 2014年 JoonSheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TCShowViewController : UIViewController

@end

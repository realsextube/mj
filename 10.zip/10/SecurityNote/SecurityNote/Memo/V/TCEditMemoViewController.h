//
//  TCEditMemoViewController.h
//  SecurityNote
//
//  Created by HTC on 14-9-30.
//  Copyright (c) 2014年 JoonSheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TCEditMemoViewController : UIViewController

@property (nonatomic, assign) int ids;

@end

//
//  ComicBookCollectionViewDelegate.swift
//  ComicApp
//
//  Created by Phil Martin on 09/10/2019.
//  Copyright © 2019 Phil Martin. All rights reserved.
//

import UIKit

class ComicBookCollectionViewDelegate: NSObject, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
//    
//    func collectionView(_ collectionView: UICollectionView,
//           layout collectionViewLayout: UICollectionViewLayout,
//           sizeForItemAt indexPath: IndexPath) -> CGSize{
//        return CGSize(width: 130, height: 210)
//    }
//    
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
//         return 10;
//    }
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
//        return 10;
//    }
    
}

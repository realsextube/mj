//
//  PrivateConstants.swift
//  ComicApp
//
//  Created by Philip Martin on 29/09/2019.
//  Copyright © 2019 Phil Martin. All rights reserved.
//

import Foundation

let privateKey = "62506b06c5b697839092ca6eac02e1d8f23683db" //"developer.marvel.com private key"
let publicKey = "452b2ec51923e10bdf4c22421a862607" //"developer.marvel.com public key"


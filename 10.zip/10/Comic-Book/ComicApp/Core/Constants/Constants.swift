//
//  Constants.swift
//  ComicApp
//
//  Created by Phil Martin on 10/09/2019.
//  Copyright © 2019 Phil Martin. All rights reserved.
//

import UIKit

let heroFontName = "BadaBoomBB"
let titleFontSize: CGFloat = 20

//
//  PoetryModel.swift
//  ChinesePoetry
//
//  Created by 成殿 on 2018/2/8.
//  Copyright © 2018年 成殿. All rights reserved.
//

import Foundation

class PoetryModel {
    var id: Int!
    var title: String?
    var author: String?
    var txt: String?
}
